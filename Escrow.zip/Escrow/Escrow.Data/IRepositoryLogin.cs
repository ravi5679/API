﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Escrow.Entity;

namespace Escrow.Data
{
  public  interface IRepositoryLogin
    {
        tblUser LoginDetail(tblUser user);
    }
}
