﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessInterface;
using Escrow.Data;
using Escrow.Entity;
using Escrow.Data.Repository;

namespace BusinessLayer
{
   public class BusinessLogin: IBusinessLogin
    {
     private   IRepositoryLogin _loginRepository;
        public BusinessLogin() {
            _loginRepository = new RepositoryLogin();
        }       
       public tblUser ValidateLoginDetail(tblUser user)
        {
          return  _loginRepository.LoginDetail(user);
        }
    }
}
