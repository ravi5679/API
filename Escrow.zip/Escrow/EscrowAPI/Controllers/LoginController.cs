﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Escrow.Entity;
using BusinessInterface;
using BusinessLayer;

namespace EscrowAPI.Controllers
{
    [RoutePrefix("api")]
    public class LoginController : ApiController
    {
        [Route("Login")]
        public Boolean GetLogin()
        {
            tblUser user = new tblUser()
            {
                Username = "Ravi",
                Password = 1234
            };
            BusinessLogin _login = new BusinessLogin();
            tblUser v= _login.ValidateLoginDetail(user); 
            return true;
        }
    }
}
