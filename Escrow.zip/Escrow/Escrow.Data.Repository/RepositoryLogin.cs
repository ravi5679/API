﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Escrow.Entity;
using Escrow.Data;
namespace Escrow.Data.Repository
{
 public class RepositoryLogin : IRepositoryLogin
    {
        EscrowConfig _context = new EscrowConfig();
      public tblUser LoginDetail(tblUser user)
        {
        var result = _context.tblUsers
                    .Where(c => c.Username == user.Username).FirstOrDefault<tblUser>();
            return result;
        }
    }
}
